﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web

Partial Class index
    Inherits System.Web.UI.Page
    'Public Class sites
    '    Private _site As String

    '    Public Property Name() As String
    '        Get
    '            Return _site
    '        End Get
    '        Private Set(ByVal value As String)
    '            _site = value
    '        End Set
    '    End Property
    'End Class
End Class
