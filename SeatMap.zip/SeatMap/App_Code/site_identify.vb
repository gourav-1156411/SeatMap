﻿Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Linq
Imports System.Web
Imports System.Web.Script.Serialization
Imports System.Web.Script.Services
Imports System.Web.Services


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class site_identify
    Inherits System.Web.Services.WebService
   
    <WebMethod()> _
    Public Function Getsites(site As String) As List(Of String)
        Dim strCon As String = ConfigurationManager.ConnectionStrings("TestConnectionString").ToString
        Dim query As String = "SELECT distinct Site FROM Floor_info where Location='" & site & "'"
        Dim Sites As New List(Of String)()
        Using con As New SqlConnection(strCon)
            con.Open()
            Using cmd As New SqlCommand(query, con)
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            Sites.Add(sdr(0).ToString)
                            End While
                    End If
                End Using
                con.Close()
                Return Sites
            End Using
        End Using
    End Function

    <WebMethod()> _
    Public Function GetTower(Site As String, Location As String) As List(Of String)
        Dim strCon As String = ConfigurationManager.ConnectionStrings("TestConnectionString").ToString
        Dim query As String = "SELECT distinct Tower FROM Floor_info where Site='" & Site & "' and Location='" & Location & "'"
        Dim Towers As New List(Of String)()
        Using con As New SqlConnection(strCon)
            con.Open()
            Using cmd As New SqlCommand(query, con)
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            Towers.Add(sdr(0).ToString)
                        End While
                    End If
                End Using
                con.Close()
                Return Towers
            End Using
        End Using
    End Function

    <WebMethod()> _
    Public Function GetFloor(Tower As String, Location As String, Site As String) As List(Of String)
        Dim strCon As String = ConfigurationManager.ConnectionStrings("TestConnectionString").ToString
        Dim query As String = "SELECT Distinct Floor FROM Floor_info Where Tower='" & Tower & "' and Location='" & Location & "' and Site='" & Site & "'"
        Dim Floor As New List(Of String)()
        Using con As New SqlConnection(strCon)
            con.Open()
            Using cmd As New SqlCommand(query, con)
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            Floor.Add(sdr(0).ToString)
                        End While
                    End If
                End Using
                con.Close()
                Return Floor
            End Using
        End Using
    End Function

End Class