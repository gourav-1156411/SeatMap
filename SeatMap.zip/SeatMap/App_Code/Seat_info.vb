﻿Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Linq
Imports System.Web
Imports System.Web.Script.Serialization
Imports System.Web.Script.Services
Imports System.Web.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Seat_info
    Inherits System.Web.Services.WebService

    Public Class seat_no
        Public Property seatno() As String
        Public Property seat_type() As String
    End Class

    Public Class seat_details
        Public Property shift() As String
        Public Property func() As String
    End Class


    <WebMethod()> _
    Public Function Getseat(loc As String, Site As String, Tower As String, floor As String) As String
        Dim strCon As String = ConfigurationManager.ConnectionStrings("TestConnectionString").ToString
        Dim query As String = "SELECT Seats FROM Floor_info Where Location='" & loc & "' and Site='" & Site & "' and Tower='" & Tower & "' and Floor='" & floor & "'"
        Dim seats As String = ""
        Using con As New SqlConnection(strCon)
            con.Open()
            Using cmd As New SqlCommand(query, con)
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            seats = sdr(0).ToString
                        End While
                    End If
                End Using
                seats = seats + 1
                con.Close()
                Return seats
            End Using
        End Using
    End Function

    <WebMethod()> _
    Public Function Getseat_numbers(loc As String, Site As String, Tower As String, floor As String) As List(Of seat_no)
        Dim strCon As String = ConfigurationManager.ConnectionStrings("TestConnectionString").ToString
        Dim query As String = "SELECT distinct Seat_No,Seat_Type FROM Seat_Details Where Location='" & loc & "' and Site='" & Site & "' and Tower='" & Tower & "' and Floor='" & floor & "'"
        Dim seat As New List(Of seat_no)()
        Using con As New SqlConnection(strCon)
            con.Open()
            Using cmd As New SqlCommand(query, con)
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            seat.Add(New seat_no() With { _
                                .seatno = sdr("Seat_No").ToString, _
                                .seat_type = sdr("Seat_Type").ToString _
                            })

                        End While
                    End If
                End Using
                con.Close()
                Return seat
            End Using
        End Using
    End Function

    <WebMethod()> _
    Public Function seat_detail(loc As String, Site As String, Tower As String, floor As String, seatno As String) As List(Of seat_details)
        Dim strCon As String = ConfigurationManager.ConnectionStrings("TestConnectionString").ToString
        Dim query As String = "SELECT distinct Shift,Func FROM Seat_Details Where Location='" & loc & "' and Site='" & Site & "' and Tower='" & Tower & "' and Floor='" & floor & "' and Seat_No='" & seatno & "'"
        Dim details As New List(Of seat_details)()
        Using con As New SqlConnection(strCon)
            con.Open()
            Using cmd As New SqlCommand(query, con)
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    If sdr.HasRows Then
                        While sdr.Read()
                            details.Add(New seat_details() With { _
                                .func = sdr("Shift").ToString, _
                                .shift = sdr("Func").ToString _
                            })

                        End While
                    End If
                End Using
                con.Close()
                Return details
            End Using
        End Using
    End Function

End Class