﻿
Partial Class Main
    Inherits System.Web.UI.MasterPage
End Class

