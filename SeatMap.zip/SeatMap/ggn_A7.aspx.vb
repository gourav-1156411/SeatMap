﻿
Partial Class ggn_A7
    Inherits System.Web.UI.Page

End Class
